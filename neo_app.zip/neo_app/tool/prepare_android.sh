#!/usr/bin/env bash
# Generates the android/ folder and applies Neo's Android settings.
# Run from the neo_app folder. Safe to run more than once.
set -e

flutter create --platforms=android --org uz.max --project-name neo_app .

M=android/app/src/main/AndroidManifest.xml
if ! grep -q 'android.permission.RECORD_AUDIO' "$M"; then
  sed -i '0,/<application/s//<uses-permission android:name="android.permission.INTERNET"\/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"\/>\n    <queries><intent><action android:name="android.intent.action.TTS_SERVICE"\/><\/intent><\/queries>\n    <application/' "$M"
fi
sed -i 's/android:label="neo_app"/android:label="Neo"/' "$M"

for f in android/app/build.gradle.kts android/app/build.gradle; do
  if [ -f "$f" ]; then
    sed -i -E 's/minSdk = flutter\.minSdkVersion/minSdk = 24/; s/minSdkVersion flutter\.minSdkVersion/minSdkVersion 24/' "$f"
  fi
done

echo "Android project ready."
