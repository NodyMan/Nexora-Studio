# Neo — Android app (v0.2, "Soft Day")

Max's admin app for Neo: a living, animated Neo you can talk to, plus Activity, Approvals, Money and Settings.

## What's inside
- **Living Neo** (`lib/neo/neo_face.dart`): spring-animated face. Eyes follow your finger, blinks, breathes, hops. Moods: idle, listening, thinking, talking, happy, sleepy (23:00–07:00), alert (approvals waiting).
- **Talk to Neo** (`lib/neo/neo_brain.dart`): type, or hold the mic. Voice is sent to the n8n backend (Groq Whisper understands Uzbek, Russian, English). Neo's reply appears in a speech bubble and is spoken aloud with the phone's voice; the mouth moves while it speaks.
- **Home**: weather, living Neo, quick asks, spent today, approvals, next task, today's activity.
- **Chat**: full history (Telegram/app/voice), live.
- **Approvals**: approve / reject what Neo wants to do.
- **Money**: this month's spending by category.
- **Settings**: kill switch, speak replies, voice language, Neo's colour, sign out.

No AI keys are in this app. It only holds the public Supabase key; the n8n backend only answers requests carrying Max's login.

## Build with GitHub (no PC setup)
1. In your repo, upload `neo_app.zip` (replace the old one).
2. Replace `.github/workflows/build.yml` with the `build.yml` file that came with this zip.
3. Wait ~10 minutes → **Releases** → download `app-release.apk` → install.
   If an older Neo is installed and Android says "App not installed", uninstall the old one first.

## Build on a PC
```
cd neo_app
bash tool/prepare_android.sh      # on Windows: run it in Git Bash
flutter pub get
flutter run                       # phone connected with USB debugging
```

## First run
1. Create your login once in Supabase → Authentication → Users → Add user.
2. Open Neo, sign in, allow the microphone when asked.
3. Hold the mic, say "Salom Neo", let go.
