import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../theme.dart';

enum NeoMood { idle, listening, thinking, talking, happy, sleepy, alert }

/// A small damped spring so every part of the face moves with a bit of life.
/// (Idea from the public-domain "Bluey" app; written fresh for Neo.)
class _Spring {
  _Spring(this.x, this.k, this.d);
  double x;
  double v = 0;
  final double k; // stiffness
  final double d; // damping ratio: 1 = no overshoot, lower = bouncier

  void step(double target, double dt) {
    final c = 2 * math.sqrt(k) * d;
    v += (k * (target - x) - c * v) * dt;
    x += v * dt;
  }
}

class NeoFrame {
  NeoFrame({
    required this.gx, required this.gy, required this.pupil, required this.lift, required this.tilt,
    required this.lean, required this.hop, required this.blush, required this.squint, required this.closed,
    required this.breathe, required this.talk, required this.mood, required this.time,
  });
  final double gx, gy, pupil, lift, tilt, lean, hop, blush, squint, closed, breathe, talk, time;
  final NeoMood mood;
}

/// Turns a mood + optional finger position into smooth, lifelike motion.
class NeoAnimator {
  final _rnd = math.Random();
  double _last = -1;
  final _gx = _Spring(0, 260, 0.82), _gy = _Spring(-0.2, 260, 0.82);
  final _pupil = _Spring(1, 160, 0.5), _lift = _Spring(0, 180, 0.55), _tilt = _Spring(0, 150, 0.6);
  final _lean = _Spring(0, 60, 0.8), _hop = _Spring(0, 260, 0.35), _blush = _Spring(0.3, 40, 1);
  final _squint = _Spring(0, 150, 0.7), _lid = _Spring(0, 120, 1);
  double _talk = 0;
  NeoMood _mood = NeoMood.idle;
  double _blinkStart = -1, _nextBlink = 2, _nextSaccade = 0, _nextJit = 0, _nextHop = 5;
  bool _dbl = false;
  Offset _wander = const Offset(0, -0.2), _jit = Offset.zero;

  double _r(double lo, double hi) => lo + _rnd.nextDouble() * (hi - lo);

  NeoFrame step(double now, NeoMood mood, Offset? pointer, double voiceLevel) {
    final dt = _last < 0 ? 0.0 : (now - _last).clamp(0.0, 1 / 20);
    _last = now;

    if (mood != _mood) {
      _mood = mood;
      _blinkStart = now;
      if (mood != NeoMood.sleepy) {
        _hop.v += 260;
        _pupil.v += 3;
      }
    }

    Offset want;
    if (pointer != null) {
      want = pointer;
    } else {
      if (now > _nextSaccade) {
        _wander = Offset(_r(-0.9, 0.9), _r(-0.8, 0.4));
        _nextSaccade = now + _r(0.6, 2.2);
      }
      want = _wander;
    }
    if (mood == NeoMood.thinking) want = Offset(0.6 + 0.08 * math.sin(now * 1.3), -0.85);
    if (mood == NeoMood.sleepy) want = const Offset(0, 0.5);
    if (now > _nextJit) {
      final a = mood == NeoMood.talking ? 0.07 : mood == NeoMood.thinking ? 0.05 : 0.02;
      _jit = Offset(_r(-a, a), _r(-a, a));
      _nextJit = now + _r(0.5, 1.4);
    }
    _gx.step(want.dx + _jit.dx, dt);
    _gy.step(want.dy + _jit.dy, dt);

    double wantTalk = 0;
    if (mood == NeoMood.talking) {
      final synthetic = math.max(0.0, 0.5 + 0.5 * math.sin(now * 19) * math.sin(now * 7.3));
      wantTalk = voiceLevel > 0 ? math.max(voiceLevel, synthetic * 0.6) : synthetic;
    }
    _talk += (wantTalk - _talk) * math.min(1.0, dt * 25);

    double wp = 1, wl = 0, wt = 0, wb = 0.3, ws = 0, wlid = 0;
    switch (mood) {
      case NeoMood.listening:
        wp = 1.15 + voiceLevel * 0.15;
        wl = 8 + voiceLevel * 6;
      case NeoMood.talking:
        wp = 1.05;
        wl = 4 + _talk * 10;
        wt = 0.05 * math.sin(now * 2.3);
      case NeoMood.thinking:
        wp = 0.9;
        wl = 4;
        wt = 0.22;
      case NeoMood.happy:
        wp = 1.2;
        wl = 12;
        wb = 0.9;
        ws = 1;
      case NeoMood.sleepy:
        wp = 0.88;
        wl = -6;
        wt = 0.12;
        wb = 0.15;
        wlid = 0.55;
      case NeoMood.alert:
        wp = 0.85;
        wl = 14;
        wt = -0.12;
      case NeoMood.idle:
        break;
    }
    _pupil.step(wp, dt);
    _lift.step(wl, dt);
    _tilt.step(wt, dt);
    _blush.step(wb, dt);
    _squint.step(ws, dt);
    _lid.step(wlid, dt);
    _lean.step(-_gx.x * 0.06, dt);

    if (now > _nextHop) {
      if (_talk < 0.05 && mood != NeoMood.sleepy) _hop.v += _r(180, 320);
      _nextHop = now + (mood == NeoMood.alert ? _r(1.2, 2) : _r(7, 14));
    }
    _hop.step(0, dt);

    final drowsy = mood == NeoMood.sleepy;
    if (now > _nextBlink) {
      _blinkStart = now;
      _dbl = !drowsy && _rnd.nextDouble() < 0.25;
      _nextBlink = now + (drowsy ? _r(1.6, 3) : _r(2, 5));
    }
    final p = (now - _blinkStart) / (drowsy ? 0.7 : 0.15);
    var closed = (p >= 0 && p <= 1) ? math.sin(math.pi * p) : 0.0;
    if (_dbl && p >= 1.3 && p <= 2.3) closed = math.sin(math.pi * (p - 1.3));
    closed = math.max(closed, _lid.x);

    return NeoFrame(
      gx: _gx.x.clamp(-1.0, 1.0), gy: _gy.x.clamp(-1.0, 1.0), pupil: _pupil.x, lift: _lift.x, tilt: _tilt.x,
      lean: _lean.x, hop: _hop.x, blush: _blush.x.clamp(0.0, 1.0), squint: _squint.x.clamp(0.0, 1.0),
      closed: closed.clamp(0.0, 1.0), breathe: 1 + 0.012 * math.sin(now * (drowsy ? 1.1 : 1.8)),
      talk: _talk, mood: mood, time: now,
    );
  }
}

/// Neo, alive. Put it in a box of any size; the face peeks up from the bottom edge.
/// [mood] and [voiceLevel] drive expressions. Touch the face and the eyes follow your finger.
class NeoFace extends StatefulWidget {
  const NeoFace({super.key, required this.mood, required this.color, this.voiceLevel = 0, this.onTap});
  final NeoMood mood;
  final Color color;
  final double voiceLevel;
  final VoidCallback? onTap;

  @override
  State<NeoFace> createState() => _NeoFaceState();
}

class _NeoFaceState extends State<NeoFace> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  final _clock = ValueNotifier<double>(0);
  final _anim = NeoAnimator();
  Offset? _pointer;
  Size _size = Size.zero;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((elapsed) => _clock.value = elapsed.inMicroseconds / 1e6)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    _clock.dispose();
    super.dispose();
  }

  void _track(Offset local) {
    if (_size == Size.zero) return;
    final s = _size.width / 350;
    final cx = (45 + 130) * s, cy = (48 + 86) * s;
    _pointer = Offset(((local.dx - cx) / (160 * s)).clamp(-1.0, 1.0), ((local.dy - cy) / (160 * s)).clamp(-1.0, 1.0));
  }

  @override
  Widget build(BuildContext context) {
    final label = 'Neo is ${widget.mood.name}';
    return Semantics(
      label: label,
      button: widget.onTap != null,
      child: LayoutBuilder(builder: (context, c) {
        _size = Size(c.maxWidth, c.maxHeight);
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: widget.onTap,
          onPanDown: (d) => _track(d.localPosition),
          onPanUpdate: (d) => _track(d.localPosition),
          onPanEnd: (_) => _pointer = null,
          onPanCancel: () => _pointer = null,
          child: CustomPaint(
            size: _size,
            painter: _FacePainter(
              repaint: _clock,
              frame: () => _anim.step(_clock.value, widget.mood, _pointer, widget.voiceLevel),
              color: widget.color,
            ),
          ),
        );
      }),
    );
  }
}

class _FacePainter extends CustomPainter {
  _FacePainter({required Listenable repaint, required this.frame, required this.color}) : super(repaint: repaint);
  final NeoFrame Function() frame;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final f = frame();
    final s = size.width / 350; // design is 350 wide
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.scale(s);
    final h = size.height / s;

    // Mood extras behind/around the head.
    if (f.mood == NeoMood.thinking) {
      for (var i = 0; i < 3; i++) {
        final o = 0.35 + 0.65 * math.max(0.0, math.sin(f.time * 4 - i * 0.8));
        canvas.drawCircle(Offset(268 + i * 18.0, 40 - i * 4.0), 4.0 + i * 1.5, Paint()..color = NeoColors.muted.withValues(alpha: o));
      }
    }
    if (f.mood == NeoMood.sleepy) {
      final tp = TextPainter(
        text: TextSpan(text: 'z z', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: NeoColors.muted.withValues(alpha: 0.7))),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(262, 26 + 6 * math.sin(f.time * 1.5)));
    }

    // Body: a big round head peeking up from the bottom edge.
    final top = h - 188 - f.hop * 0.12;
    canvas.save();
    canvas.translate(45 + 130, top + 260);
    canvas.rotate(f.lean);
    canvas.scale(f.breathe);
    canvas.translate(-130, -260);
    final skin = Paint()..color = color;
    canvas.drawCircle(const Offset(130, 130), 130, skin);

    // Cheeks.
    final blush = Paint()
      ..color = const Color(0xFFE2475C).withValues(alpha: f.blush * 0.7)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
    canvas.drawOval(const Rect.fromLTWH(52, 124, 36, 16), blush);
    canvas.drawOval(const Rect.fromLTWH(172, 124, 36, 16), blush);

    // Brows.
    final brow = Paint()..color = NeoColors.ink;
    for (final side in [-1, 1]) {
      final cx = side < 0 ? 79.0 : 181.0;
      canvas.save();
      canvas.translate(cx, 40 - f.lift);
      canvas.rotate(side < 0 ? -f.tilt : f.tilt);
      canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-21, -4, 42, 8), const Radius.circular(4)), brow);
      canvas.restore();
    }

    // Eyes.
    for (final ex in [47.0, 149.0]) {
      final eye = Rect.fromLTWH(ex, 54, 64, 64);
      canvas.save();
      canvas.clipPath(Path()..addOval(eye));
      canvas.drawOval(eye, Paint()..color = Colors.white);
      final ps = 30 * f.pupil;
      final pc = Offset(ex + 32 + f.gx * 13, 54 + 32 + f.gy * 13);
      canvas.drawCircle(pc, ps / 2, Paint()..color = NeoColors.ink);
      canvas.drawCircle(pc + Offset(-ps * 0.12, -ps * 0.18), 4.5, Paint()..color = Colors.white);
      // Eyelid (blink / sleepy) from the top, happy squint from the bottom.
      canvas.drawRect(Rect.fromLTWH(ex, 54, 64, f.closed * 66), skin);
      if (f.squint > 0.01) {
        final sh = f.squint * 34;
        canvas.drawOval(Rect.fromLTWH(ex - 6, 54 + 64 + 6 - sh, 76, sh * 2), skin);
      }
      canvas.restore();
    }

    // Mouth.
    final ink = Paint()..color = NeoColors.ink;
    if (f.squint > 0.5) {
      final smile = Path()
        ..moveTo(111, 148)
        ..lineTo(149, 148)
        ..arcToPoint(const Offset(111, 148), radius: const Radius.circular(19), clockwise: true)
        ..close();
      canvas.drawPath(smile, ink);
    } else {
      final w = 22 + f.talk * 8, mh = 9 + f.talk * 20;
      canvas.drawOval(Rect.fromCenter(center: Offset(130, 150 + mh / 2), width: w, height: mh), ink);
    }
    canvas.restore();
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _FacePainter old) => true;
}
