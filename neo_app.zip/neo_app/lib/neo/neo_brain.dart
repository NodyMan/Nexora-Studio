import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../theme.dart';
import 'neo_face.dart';

final supabase = Supabase.instance.client;

/// Everything Neo "is" right now: mood, voice, last words. One shared instance.
class NeoBrain extends ChangeNotifier {
  NeoBrain._();
  static final NeoBrain instance = NeoBrain._();

  // ---- state the UI reads ----
  NeoMood _base = NeoMood.idle; // listening / thinking / talking / happy while busy
  bool _busy = false;
  int pendingApprovals = 0;
  double voiceLevel = 0; // 0..1, mic loudness while listening, speech pulse while talking
  String? lastReply; // shown in the speech bubble for a few seconds
  bool voiceReplies = true;
  String replyLanguage = 'same_as_user';
  bool killSwitch = false;

  /// Separate, slow-changing notifiers so big widgets (theme, chat list)
  /// don't rebuild on every mic/voice level tick.
  final colorListenable = ValueNotifier<Color>(NeoColors.accents.first);
  final pendingListenable = ValueNotifier<String?>(null); // your message while Neo is thinking
  Color get color => colorListenable.value;
  String? get pendingUserText => pendingListenable.value;
  set pendingUserText(String? v) => pendingListenable.value = v;

  NeoMood get mood {
    if (_busy || _base != NeoMood.idle) return _base;
    final h = DateTime.now().hour;
    if (h >= 23 || h < 7) return NeoMood.sleepy;
    if (pendingApprovals > 0) return NeoMood.alert;
    return NeoMood.idle;
  }

  bool get isListening => _base == NeoMood.listening;
  bool get isBusy => _busy;

  // ---- internals ----
  final _recorder = AudioRecorder();
  final _tts = FlutterTts();
  StreamSubscription<Amplitude>? _ampSub;
  StreamSubscription<List<Map<String, dynamic>>>? _approvalsSub, _settingsSub;
  Timer? _bubbleTimer, _happyTimer, _talkPulse;
  bool _started = false;

  Future<void> start() async {
    if (_started) return;
    _started = true;
    _approvalsSub = supabase
        .from('approvals')
        .stream(primaryKey: ['id'])
        .eq('status', 'pending')
        .listen((rows) {
      pendingApprovals = rows.length;
      notifyListeners();
    }, onError: (_) {});
    _settingsSub = supabase.from('settings').stream(primaryKey: ['key']).listen((rows) {
      for (final r in rows) {
        final v = r['value'];
        switch (r['key']) {
          case 'voice_replies':
            voiceReplies = v != false;
          case 'reply_language':
            replyLanguage = v?.toString() ?? 'same_as_user';
          case 'kill_switch':
            killSwitch = v == true;
          case 'neo_color':
            final i = int.tryParse(v.toString());
            if (i != null && i >= 0 && i < NeoColors.accents.length) colorListenable.value = NeoColors.accents[i];
        }
      }
      notifyListeners();
    }, onError: (_) {});

    await _tts.awaitSpeakCompletion(true);
    _tts.setStartHandler(() {
      _setBase(NeoMood.talking);
      _talkPulse?.cancel();
      final rnd = math.Random();
      _talkPulse = Timer.periodic(const Duration(milliseconds: 90), (_) {
        voiceLevel = 0.35 + rnd.nextDouble() * 0.65;
        notifyListeners();
      });
    });
    void doneTalking() {
      _talkPulse?.cancel();
      voiceLevel = 0;
      _happyThenIdle();
    }
    _tts.setCompletionHandler(doneTalking);
    _tts.setCancelHandler(doneTalking);
    _tts.setErrorHandler((_) => doneTalking());
  }

  Future<void> stop() async {
    await _approvalsSub?.cancel();
    await _settingsSub?.cancel();
    _started = false;
  }

  void _setBase(NeoMood m) {
    _base = m;
    notifyListeners();
  }

  void _happyThenIdle() {
    _busy = false;
    _setBase(NeoMood.happy);
    _happyTimer?.cancel();
    _happyTimer = Timer(const Duration(milliseconds: 1800), () => _setBase(NeoMood.idle));
  }

  void poke() {
    if (_busy) return;
    _setBase(NeoMood.happy);
    _happyTimer?.cancel();
    _happyTimer = Timer(const Duration(milliseconds: 1500), () => _setBase(NeoMood.idle));
  }

  void _showBubble(String text) {
    lastReply = text;
    _bubbleTimer?.cancel();
    _bubbleTimer = Timer(Duration(seconds: math.min(14, 4 + text.length ~/ 25)), () {
      lastReply = null;
      notifyListeners();
    });
    notifyListeners();
  }

  // ---- talking to Neo ----

  Future<String?> sendText(String text) async {
    final t = text.trim();
    if (t.isEmpty || _busy) return null;
    return _ask({'text': t}, shownText: t, speak: voiceReplies);
  }

  Future<bool> startListening() async {
    if (_busy) return false;
    if (!await _recorder.hasPermission()) return false;
    await _tts.stop();
    final dir = await getTemporaryDirectory();
    await _recorder.start(
      const RecordConfig(encoder: AudioEncoder.aacLc, sampleRate: 16000, numChannels: 1, bitRate: 64000),
      path: '${dir.path}/neo_voice.m4a',
    );
    _ampSub = _recorder.onAmplitudeChanged(const Duration(milliseconds: 100)).listen((a) {
      // dBFS: about -45 (quiet) … 0 (loud)
      voiceLevel = ((a.current + 45) / 45).clamp(0.0, 1.0);
      notifyListeners();
    });
    _setBase(NeoMood.listening);
    return true;
  }

  Future<String?> stopListeningAndSend() async {
    if (!isListening) return null;
    await _ampSub?.cancel();
    voiceLevel = 0;
    final path = await _recorder.stop();
    if (path == null) {
      _setBase(NeoMood.idle);
      return null;
    }
    final file = File(path);
    final bytes = await file.readAsBytes();
    if (bytes.length < 3000) {
      // shorter than ~half a second: treat as an accidental tap
      _setBase(NeoMood.idle);
      return null;
    }
    return _ask({'audio_b64': base64Encode(bytes), 'mime': 'audio/mp4'}, shownText: '🎙 …', speak: true);
  }

  Future<void> cancelListening() async {
    await _ampSub?.cancel();
    voiceLevel = 0;
    await _recorder.cancel();
    _setBase(NeoMood.idle);
  }

  Future<String?> _ask(Map<String, dynamic> body, {required String shownText, required bool speak}) async {
    final token = supabase.auth.currentSession?.accessToken;
    if (token == null) return null;
    _busy = true;
    pendingUserText = shownText;
    _setBase(NeoMood.thinking);
    try {
      final res = await http
          .post(Uri.parse(neoWebhookUrl),
              headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
              body: jsonEncode(body))
          .timeout(const Duration(seconds: 90));
      pendingUserText = null;
      if (res.statusCode != 200) throw Exception('Neo answered ${res.statusCode}');
      final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final reply = (data['reply'] ?? '').toString().trim();
      if (reply.isEmpty) throw Exception('empty reply');
      _showBubble(reply);
      if (speak) {
        await _speak(reply);
      } else {
        _happyThenIdle();
      }
      return reply;
    } catch (e) {
      pendingUserText = null;
      _busy = false;
      _showBubble("I couldn't reach my brain just now. Check the internet and try again.");
      _setBase(NeoMood.idle);
      return null;
    }
  }

  Future<void> _speak(String text) async {
    String lang;
    if (replyLanguage == 'ru' || (replyLanguage == 'same_as_user' && RegExp(r'[А-Яа-яЁё]').hasMatch(text))) {
      lang = 'ru-RU';
    } else if (replyLanguage == 'uz' || (replyLanguage == 'same_as_user' && RegExp(r"(o‘|g‘|oʻ|gʻ|\bva\b|\bmen\b|\bsiz\b)", caseSensitive: false).hasMatch(text))) {
      lang = 'uz-UZ';
    } else {
      lang = 'en-US';
    }
    try {
      final ok = await _tts.isLanguageAvailable(lang);
      await _tts.setLanguage(ok == true ? lang : (lang == 'uz-UZ' ? 'ru-RU' : 'en-US'));
      await _tts.setSpeechRate(0.5);
      await _tts.speak(text); // waits until speaking ends (awaitSpeakCompletion)
      if (_busy) {
        // Some phones never fire the completion callback; don't leave Neo stuck.
        _talkPulse?.cancel();
        voiceLevel = 0;
        _happyThenIdle();
      }
    } catch (_) {
      _talkPulse?.cancel();
      _happyThenIdle();
    }
  }

  Future<void> stopSpeaking() => _tts.stop();

  Future<void> saveSetting(String key, Object value) async {
    await supabase.from('settings').upsert({'key': key, 'value': value});
  }
}

final neo = NeoBrain.instance;
