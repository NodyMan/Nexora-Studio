import 'package:flutter/material.dart';

import '../neo/neo_brain.dart';
import '../theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _set(BuildContext context, String key, Object value) async {
    try {
      await neo.saveSetting(key, value);
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Not saved: $e')));
    }
  }

  Future<void> _kill(BuildContext context, bool on) async {
    if (!on) return _set(context, 'kill_switch', false);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Stop Neo?'),
        content: const Text('Neo will stop taking any actions until you turn this off. It can still read and chat.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Stop Neo')),
        ],
      ),
    );
    if (ok == true && context.mounted) await _set(context, 'kill_switch', true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListenableBuilder(
        listenable: neo,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
          children: [
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: Icon(Icons.pan_tool_outlined, color: neo.killSwitch ? NeoColors.danger : null),
                    title: const Text('Kill switch'),
                    subtitle: Text(neo.killSwitch ? 'Neo is stopped — no actions will run' : 'Neo is running'),
                    value: neo.killSwitch,
                    onChanged: (v) => _kill(context, v),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: const Icon(Icons.record_voice_over_outlined),
                    title: const Text('Speak replies aloud'),
                    subtitle: const Text('Voice messages are always answered out loud'),
                    value: neo.voiceReplies,
                    onChanged: (v) => _set(context, 'voice_replies', v),
                  ),
                  ListTile(
                    leading: const Icon(Icons.translate),
                    title: const Text('Neo\'s voice language'),
                    trailing: DropdownButton<String>(
                      value: const ['same_as_user', 'uz', 'ru', 'en'].contains(neo.replyLanguage) ? neo.replyLanguage : 'same_as_user',
                      underline: const SizedBox.shrink(),
                      items: const [
                        DropdownMenuItem(value: 'same_as_user', child: Text('Auto')),
                        DropdownMenuItem(value: 'uz', child: Text('Oʻzbekcha')),
                        DropdownMenuItem(value: 'ru', child: Text('Русский')),
                        DropdownMenuItem(value: 'en', child: Text('English')),
                      ],
                      onChanged: (v) => v == null ? null : _set(context, 'reply_language', v),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Neo\'s colour', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      for (var i = 0; i < NeoColors.accents.length; i++)
                        Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: Semantics(
                            button: true,
                            selected: neo.color == NeoColors.accents[i],
                            label: ['Coral', 'Sage', 'Butter', 'Periwinkle'][i],
                            child: GestureDetector(
                              onTap: () => _set(context, 'neo_color', i),
                              child: Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: NeoColors.accents[i],
                                  shape: BoxShape.circle,
                                  border: Border.all(color: neo.color == NeoColors.accents[i] ? NeoColors.ink : Colors.transparent, width: 3),
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Sign out'),
                subtitle: Text(supabase.auth.currentUser?.email ?? ''),
                onTap: () async {
                  await supabase.auth.signOut();
                  if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
