import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../neo/neo_brain.dart';
import '../theme.dart';

/// This month's spending from the transactions table.
/// Spending = debit rows of type purchase / p2p / withdrawal / fee.
/// Refunds, reversals, top-ups and moves between Max's own cards are not spending.
class MoneyScreen extends StatefulWidget {
  const MoneyScreen({super.key});

  @override
  State<MoneyScreen> createState() => _MoneyScreenState();
}

class _MoneyScreenState extends State<MoneyScreen> with AutomaticKeepAliveClientMixin {
  late Future<List<Map<String, dynamic>>> _future = _load();
  static const _spendTypes = {'purchase', 'p2p', 'withdrawal', 'fee'};

  Future<List<Map<String, dynamic>>> _load() {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month).toUtc().toIso8601String();
    return supabase.from('transactions').select().gte('ts', start).order('ts', ascending: false);
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final t = Theme.of(context).textTheme;
    return RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (context, snap) {
          if (snap.hasError) {
            return ListView(children: [Padding(padding: const EdgeInsets.all(24), child: Text('Error: ${snap.error}'))]);
          }
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final rows = snap.data!;
          final totals = <String, double>{};
          final byCat = <String, double>{};
          for (final r in rows) {
            if (r['direction'] != 'debit' || !_spendTypes.contains(r['type'])) continue;
            final a = (r['amount'] as num?)?.toDouble() ?? 0;
            final cur = r['currency']?.toString() ?? 'UZS';
            totals[cur] = (totals[cur] ?? 0) + a;
            if (cur == 'UZS') {
              final c = r['category']?.toString() ?? 'Uncategorized';
              byCat[c] = (byCat[c] ?? 0) + a;
            }
          }
          final cats = byCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
          final maxCat = cats.isEmpty ? 1.0 : cats.first.value;

          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            children: [
              Text('Money', style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              ListenableBuilder(
                listenable: neo,
                builder: (context, _) => SoftCard(
                  color: NeoColors.ink,
                  padding: const EdgeInsets.all(20),
                  radius: 28,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Spent in ${DateFormat('MMMM').format(DateTime.now())}', style: const TextStyle(color: NeoColors.onInkMuted)),
                      const SizedBox(height: 6),
                      if (totals.isEmpty)
                        const Text('0 UZS', style: TextStyle(color: NeoColors.onInk, fontSize: 32, fontWeight: FontWeight.w800))
                      else
                        for (final e in totals.entries)
                          Text('${formatSum(e.value)} ${e.key}',
                              style: const TextStyle(color: NeoColors.onInk, fontSize: 32, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                      const SizedBox(height: 6),
                      Text(rows.isEmpty ? 'Neo will fill this in once card tracking is connected.' : '${rows.length} transactions this month',
                          style: TextStyle(color: neo.color)),
                    ],
                  ),
                ),
              ),
              if (cats.isNotEmpty) ...[
                const SizedBox(height: 20),
                Text('By category', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w700, color: NeoColors.muted)),
                const SizedBox(height: 8),
                SoftCard(
                  child: Column(
                    children: [
                      for (final c in cats)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Column(
                            children: [
                              Row(children: [Expanded(child: Text(c.key, style: const TextStyle(fontWeight: FontWeight.w600))), Text(formatSum(c.value))]),
                              const SizedBox(height: 6),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(
                                  value: c.value / maxCat,
                                  minHeight: 8,
                                  backgroundColor: NeoColors.ground,
                                  color: neo.color,
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 20),
              Text('Transactions', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w700, color: NeoColors.muted)),
              const SizedBox(height: 8),
              if (rows.isEmpty)
                const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Text('No transactions this month yet.', style: TextStyle(color: NeoColors.muted))),
              for (final r in rows) _TxTile(row: r),
            ],
          );
        },
      ),
    );
  }
}

class _TxTile extends StatelessWidget {
  const _TxTile({required this.row});
  final Map<String, dynamic> row;

  @override
  Widget build(BuildContext context) {
    final ts = DateTime.tryParse(row['ts']?.toString() ?? '')?.toLocal();
    final debit = row['direction'] == 'debit';
    final amount = (row['amount'] as num?)?.toDouble() ?? 0;
    final card = row['card_mask'] != null ? ' · *${row['card_mask']}' : '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SoftCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(row['merchant_norm']?.toString() ?? row['merchant_raw']?.toString() ?? row['type']?.toString() ?? '',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  Text('${row['category'] ?? 'Uncategorized'}$card${ts != null ? ' · ${DateFormat('d MMM HH:mm').format(ts)}' : ''}',
                      style: const TextStyle(color: NeoColors.muted, fontSize: 12)),
                ],
              ),
            ),
            Text('${debit ? '−' : '+'}${formatSum(amount)} ${row['currency'] ?? 'UZS'}',
                style: TextStyle(fontWeight: FontWeight.w700, color: debit ? NeoColors.ink : NeoColors.good)),
          ],
        ),
      ),
    );
  }
}
