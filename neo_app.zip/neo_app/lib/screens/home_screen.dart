import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import '../config.dart';
import '../neo/neo_brain.dart';
import '../neo/neo_face.dart';
import '../theme.dart';
import '../widgets/talk_bar.dart';
import 'activity_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.onOpenTab});
  final void Function(int tab) onOpenTab;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with AutomaticKeepAliveClientMixin {
  String? _weather;
  late Future<_Today> _today = _loadToday();

  late final Stream<List<Map<String, dynamic>>> _activity =
      supabase.from('activity_log').stream(primaryKey: ['id']).order('ts', ascending: false).limit(3);

  static const _spendTypes = {'purchase', 'p2p', 'withdrawal', 'fee'};
  static const _quick = ['Summarise my day', 'What did I spend?', 'Remind me in 1 hour to stretch'];

  @override
  void initState() {
    super.initState();
    _loadWeather();
  }

  Future<void> _loadWeather() async {
    try {
      final r = await http
          .get(Uri.parse('https://api.open-meteo.com/v1/forecast?latitude=$homeLat&longitude=$homeLon&current=temperature_2m,weather_code&timezone=Asia%2FTashkent'))
          .timeout(const Duration(seconds: 8));
      final j = jsonDecode(r.body) as Map<String, dynamic>;
      final cur = j['current'] as Map<String, dynamic>;
      final code = (cur['weather_code'] as num).toInt();
      if (!mounted) return;
      setState(() => _weather ='${(cur['temperature_2m'] as num).round()}° ${_weatherWord(code)}');
    } catch (_) {}
  }

  static String _weatherWord(int c) {
    if (c == 0) return 'clear';
    if (c <= 2) return 'partly cloudy';
    if (c == 3) return 'cloudy';
    if (c <= 48) return 'foggy';
    if (c <= 67 || (c >= 80 && c <= 82)) return 'rainy';
    if (c <= 77 || c == 85 || c == 86) return 'snowy';
    return 'stormy';
  }

  Future<_Today> _loadToday() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day).toUtc().toIso8601String();
    double spent = 0;
    int payments = 0;
    Map<String, dynamic>? next;
    try {
      final tx = await supabase.from('transactions').select('amount,currency,direction,type').gte('ts', start);
      for (final r in tx) {
        if (r['direction'] == 'debit' && _spendTypes.contains(r['type']) && (r['currency'] ?? 'UZS') == 'UZS') {
          spent += (r['amount'] as num?)?.toDouble() ?? 0;
          payments++;
        }
      }
    } catch (_) {}
    try {
      final tasks = await supabase
          .from('tasks')
          .select('title,due')
          .eq('status', 'open')
          .gte('due', now.toUtc().toIso8601String())
          .order('due', ascending: true)
          .limit(1);
      if (tasks.isNotEmpty) next = tasks.first;
    } catch (_) {}
    return _Today(spent, payments, next);
  }

  Future<void> _refresh() async {
    setState(() => _today = _loadToday());
    await Future.wait([_today, _loadWeather()]);
  }

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 5) return 'Still up, Max?';
    if (h < 12) return 'Morning, Max';
    if (h < 18) return 'Afternoon, Max';
    return 'Evening, Max';
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final t = Theme.of(context).textTheme;
    final date = DateFormat('EEE, d MMM').format(DateTime.now());

    return Column(
      children: [
        Expanded(
          child: RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_weather == null ? date : '$date · $_weather', style: t.bodyMedium?.copyWith(color: NeoColors.muted)),
                          Text(_greeting(), style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                        ],
                      ),
                    ),
                    IconButton.filled(
                      tooltip: 'Settings',
                      style: IconButton.styleFrom(backgroundColor: NeoColors.card, foregroundColor: NeoColors.ink, fixedSize: const Size(48, 48)),
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
                      icon: const Icon(Icons.tune_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // Living Neo
                ListenableBuilder(
                  listenable: neo,
                  builder: (context, _) => SoftCard(
                    padding: EdgeInsets.zero,
                    radius: 28,
                    child: SizedBox(
                      height: 236,
                      child: Stack(
                        children: [
                          Positioned.fill(
                            child: NeoFace(mood: neo.mood, color: neo.color, voiceLevel: neo.voiceLevel, onTap: neo.poke),
                          ),
                          if (neo.lastReply != null)
                            Positioned(left: 14, top: 14, child: SpeechBubble(text: neo.lastReply!)),
                          if (neo.lastReply == null && neo.mood == NeoMood.alert)
                            Positioned(
                              left: 14,
                              top: 14,
                              child: GestureDetector(
                                onTap: () => widget.onOpenTab(2),
                                child: SpeechBubble(text: 'Psst — ${neo.pendingApprovals} thing${neo.pendingApprovals == 1 ? '' : 's'} need your OK.'),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                // Quick asks
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final q in _quick)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ActionChip(
                            label: Text(q),
                            backgroundColor: NeoColors.card,
                            side: const BorderSide(color: NeoColors.line),
                            shape: const StadiumBorder(),
                            labelStyle: const TextStyle(fontWeight: FontWeight.w600, color: NeoColors.ink),
                            onPressed: () => neo.sendText(q),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                FutureBuilder<_Today>(
                  future: _today,
                  builder: (context, snap) {
                    final d = snap.data;
                    return Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: SoftCard(
                                onTap: () => widget.onOpenTab(3),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Spent today', style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                                    const SizedBox(height: 6),
                                    Text(d == null ? '…' : formatSum(d.spent), style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                                    const SizedBox(height: 4),
                                    Text(d == null ? 'UZS' : 'UZS · ${d.payments} payment${d.payments == 1 ? '' : 's'}',
                                        style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ListenableBuilder(
                                listenable: neo,
                                builder: (context, _) => SoftCard(
                                  color: NeoColors.ink,
                                  onTap: () => widget.onOpenTab(2),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('Approvals', style: t.bodySmall?.copyWith(color: NeoColors.onInkMuted)),
                                      const SizedBox(height: 6),
                                      Text(neo.pendingApprovals == 0 ? 'All clear' : '${neo.pendingApprovals} waiting',
                                          style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800, color: NeoColors.onInk)),
                                      const SizedBox(height: 4),
                                      Text(neo.pendingApprovals == 0 ? 'Nothing to review' : 'Review now →',
                                          style: t.bodySmall?.copyWith(color: neo.color)),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (d?.next != null) ...[
                          const SizedBox(height: 12),
                          SoftCard(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                            child: Row(
                              children: [
                                Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(color: NeoColors.ground, borderRadius: BorderRadius.circular(16)),
                                  child: const Icon(Icons.alarm_rounded),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(d!.next!['title']?.toString() ?? '', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                                      Text('Next · ${DateFormat('EEE HH:mm').format(DateTime.parse(d.next!['due'].toString()).toLocal())}',
                                          style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    );
                  },
                ),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(child: Text('Today', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w700, color: NeoColors.muted))),
                    TextButton(
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ActivityScreen())),
                      child: const Text('See all', style: TextStyle(color: NeoColors.ink, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                StreamBuilder<List<Map<String, dynamic>>>(
                  stream: _activity,
                  builder: (context, snap) {
                    final rows = snap.data ?? const [];
                    if (rows.isEmpty) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Text('Nothing yet — say hi to Neo.', style: t.bodyMedium?.copyWith(color: NeoColors.muted)),
                      );
                    }
                    return Column(
                      children: [
                        for (final r in rows)
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Row(
                              children: [
                                Expanded(child: Text(r['action']?.toString() ?? '', style: t.bodyMedium)),
                                Text(_hm(r['ts']), style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                              ],
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 4, 20, 8),
          child: TalkBar(),
        ),
      ],
    );
  }

  static String _hm(Object? ts) {
    final d = DateTime.tryParse(ts?.toString() ?? '')?.toLocal();
    return d == null ? '' : DateFormat('HH:mm').format(d);
  }
}

class _Today {
  _Today(this.spent, this.payments, this.next);
  final double spent;
  final int payments;
  final Map<String, dynamic>? next;
}
